"""Declares the current version for use in setuptools and the like"""
__version__ = '3.1.6'
